#!/bin/bash

adduser --disabled-password --gecos "" bob
echo 'bob:ChangeMe!' | chpasswd

adduser --disabled-password --gecos "" frank
echo 'frank:ChangeMe!' | chpasswd

adduser --disabled-password --gecos "" alice
echo 'alice:ChangeMe!' | chpasswd

